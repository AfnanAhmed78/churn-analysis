# 📉 Customer Churn Analysis & Retention Intelligence

An end-to-end **churn analytics pipeline** built with **SQL + Python**, using a relational subscription dataset
(customer, subscription, and support tables). The project identifies **who is churning, why, and when**,
quantifies **revenue at risk**, and turns the findings into **actionable retention recommendations**.

> Built as a portfolio data analytics project — patterns shown here apply broadly to SaaS, OTT/streaming,
> e-commerce, fintech, and telecom subscription businesses.

---

## 🧩 Business Problem

In any subscription business, retention is the difference between compounding growth and a leaky bucket.
This project answers three core questions:

- **Who** — which customers have already churned, or are at high risk of churning?
- **Why** — which behaviors/signals (plan, contract type, support escalations) precede a cancellation?
- **When** — is there a "danger zone" in the customer journey where churn risk spikes?

**Churn definition used:** a subscription is considered churned once its `cancellation_date` is populated.

---

## 🗂️ Dataset

Data lives in a relational SQLite database (`data/customer_churn.db`), with a raw Excel source
(`data/customer_churn_data_raw.xlsx`) provided as a fallback / seed file.

| Table | Grain | Key columns |
|---|---|---|
| `db_customer` | 1 row / customer | `customerid`, name, country, state, gender, dob |
| `db_subscription` | 1 row / customer | plan_type, contract_type, monthly_charges, cancellation_date, cancellation_reason, cltv, churn_score |
| `db_support` | 1 row / support ticket | complaint_date, escalations (Y/N), csat_score |

---

## 🛠️ Tech Stack

- **Python**: `pandas`, `numpy`
- **SQL**: SQLite (`sqlite3`)
- **Visualization**: `matplotlib`, `seaborn`
- **Environment**: Jupyter Notebook

---

## 🔬 Methodology

1. **Relational data extraction** — connect Python to SQLite and pull all three tables via SQL queries.
2. **Data cleaning** — per-table cleanup: renaming, dropping unused columns, correcting data types,
   standardizing categorical values, and imputing missing values from related fields.
3. **Feature engineering** — `churn_flag`, `tenure_days`, `churn_risk` tier (Low/Medium/High from `churn_score`),
   `complaint_count`, and numeric encodings for correlation analysis.
4. **Joining** — merge subscription (grain of analysis) with customer and support data on `customerid`.
5. **KPI calculation** — churn rate, retention rate, ARPU, revenue at risk, CLTV lost, escalation rate,
   and churn broken out by plan, contract type, and state.
6. **Visualization** — trend lines, bar charts, correlation heatmap, pairplot, and multi-dimensional
   comparison plots (matplotlib + seaborn).
7. **Insight synthesis** — translate the technical findings into a prioritized retention strategy.

---

## 📊 Key Findings

| Metric | Value |
|---|---|
| Churn Rate | 28.6% |
| Retention Rate | 71.4% |
| ARPU | ₹18.85 |
| Avg. Customer Tenure | ~1,505 days (~4.1 years) |
| Revenue at Risk (churned) | 18.7% of total monthly revenue |
| CLTV Lost to Churn | 2,047 |
| Escalation Rate | 19.0% |
| Correlation (Support Escalation ↔ Churn) | 0.77 (strong positive) |

**Headline insight:** month-to-month contract subscribers churn at a dramatically higher rate than annual
subscribers, and customers who escalate a support ticket are far more likely to churn — support experience is
a *leading* indicator of churn risk, not just a lagging symptom.

**Recommendations:**
1. Incentivize the shift from monthly → annual contracts (the single highest-leverage retention lever).
2. Route any escalated support ticket to a proactive retention/save desk.
3. Prioritize retention outreach using `churn_risk × CLTV` to protect the most revenue per effort.
4. Investigate high-churn states for local root causes (pricing, service quality, competitors).
5. Track cancellation reasons monthly as an early-warning signal.

*(Full breakdown, charts, and business narrative are in the notebook.)*

---

## 📁 Project Structure

```
churn-analysis-project/
├── README.md
├── requirements.txt
├── data/
│   ├── customer_churn.db              # SQLite database (source of truth)
│   └── customer_churn_data_raw.xlsx   # Raw Excel source (fallback/seed)
├── notebook/
│   └── churn_analysis.ipynb           # Full, executed, end-to-end analysis
└── output/
    └── exported_churn_data.csv        # Cleaned, merged, analysis-ready dataset
```

---

## ▶️ How to Run

```bash
git clone <your-repo-url>
cd churn-analysis-project
pip install -r requirements.txt
jupyter notebook notebook/churn_analysis.ipynb
```

The notebook runs **end-to-end with zero errors**. If `data/customer_churn.db` is ever missing, the notebook
automatically rebuilds it from `data/customer_churn_data_raw.xlsx`.

---

## 📌 Notes

- Dataset size is intentionally small (21 customers) — this is a demonstration project designed to showcase the
  full SQL → Python → insights workflow end-to-end. The same pipeline scales directly to larger production
  datasets (millions of rows) with no structural changes.
